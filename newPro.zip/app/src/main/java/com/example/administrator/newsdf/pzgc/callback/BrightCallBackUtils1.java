package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/6/21 0021.
 */

public class BrightCallBackUtils1 {
    private static BrightCallBack mCallBack;

    public static void setCallBack(BrightCallBack callBack) {
        mCallBack = callBack;
    }

    public static void CallBackMethod() {
        mCallBack.bright();
    }

}
