package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by 10942 on 2018/7/3 0003.
 */

public interface OnDismissListener {
     void onDismiss(Object o);
}
