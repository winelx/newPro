package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/4/2 0002.
 */

public interface JPushCallBack {
    void doSomeThing();
}
