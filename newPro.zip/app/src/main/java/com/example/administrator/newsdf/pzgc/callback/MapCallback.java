package com.example.administrator.newsdf.pzgc.callback;

import java.util.Map;

/**
 * Created by Administrator on 2018/8/23 0023.
 */

public interface MapCallback {
    void getdata(Map<String, Object> map);
}
