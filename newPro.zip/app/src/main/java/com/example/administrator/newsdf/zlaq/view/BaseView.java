package com.example.administrator.newsdf.zlaq.view;

/**
 * Created by Administrator on 2018/6/29 0029.
 */

public interface BaseView {

    void showError(String msg);

    void useNightMode(boolean isNight);

}