package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by 10942 on 2018/8/26 0026.
 */

public interface CheckTaskCallback {
  void   updata();
}
