package com.example.administrator.newsdf.pzgc.view;

/**
 * Created by Administrator on 2018/1/15 0015.
 */

public interface IPieElement {
    float getValue();

    /**
     * html色值
     *
     * @return
     */
    String getColor();

    String getDescription();
}
