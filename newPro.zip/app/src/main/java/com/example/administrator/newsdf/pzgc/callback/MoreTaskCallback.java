package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/6/26 0026.
 */

public interface MoreTaskCallback {
    void newData();
}
