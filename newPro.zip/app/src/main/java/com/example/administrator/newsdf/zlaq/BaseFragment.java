package com.example.administrator.newsdf.zlaq;

import android.support.v4.app.Fragment;

/**
 * Created by Administrator on 2018/6/28 0028.
 */

public class BaseFragment extends Fragment {
}
