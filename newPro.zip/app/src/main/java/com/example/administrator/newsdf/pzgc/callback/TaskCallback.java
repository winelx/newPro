package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/4/3 0003.
 */

public interface TaskCallback {
    void  taskCallback();
}
