package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/7/18 0018.
 */

public interface AuditDetailsrefreshCallback {
    void refreshs();
}
