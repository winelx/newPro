package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/8/6 0006.
 */

public interface CategoryCallback {
    void updata(String str,String str1);
}
