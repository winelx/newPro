package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/4/4 0004.
 */

public interface OgranCallback {
    void  taskCallback();
}
