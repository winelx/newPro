package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by 10942 on 2018/8/27 0027.
 */

public interface CheckCallback {
    void update(String id);
}
