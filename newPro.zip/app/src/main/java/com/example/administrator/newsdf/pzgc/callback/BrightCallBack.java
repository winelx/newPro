package com.example.administrator.newsdf.pzgc.callback;

/**
 *
 * @author lx
 * @date 2018/6/21 0021
 */

public interface BrightCallBack {
    void bright();
}
