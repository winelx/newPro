package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/8/28 0028.
 */

public interface CheckCallback3 {
    void update(String id);
}
