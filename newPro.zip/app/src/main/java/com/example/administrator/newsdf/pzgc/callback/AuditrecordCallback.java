package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/7/18 0018.
 * 点击审核通或者打回，刷新任务列表界面
 */

public interface AuditrecordCallback {
    void updata();
}
