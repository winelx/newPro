package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/7/6 0006.
 * 亮点功能界面刷新viewpager的Fragment
 */

public interface BridhtFragmentCallback {
    void  updata();

}
