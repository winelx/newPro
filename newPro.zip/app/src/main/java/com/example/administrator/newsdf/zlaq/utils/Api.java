package com.example.administrator.newsdf.zlaq.utils;

/**
 * Created by Administrator on 2018/6/29 0029.
 */

public class Api {
    public static final String NETWORK = "http://117.187.27.78:58081/pzgc/";
    public static final String LOGIN = "http://117.187.27.78:58081/pzgc/admin/login";

}
