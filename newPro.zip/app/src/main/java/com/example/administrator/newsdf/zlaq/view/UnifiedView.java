package com.example.administrator.newsdf.zlaq.view;

/**
 * Created by Administrator on 2018/6/29 0029.
 */

public interface UnifiedView {
    void successful();
}
