package com.example.administrator.newsdf.pzgc.bean;

/**
 * Created by Administrator on 2018/1/16 0016.
 */

public class Fr_work_pie {
    String name;
    int num;
    String color;

    public Fr_work_pie(String name, int num, String color) {
        this.name = name;
        this.num = num;
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
