package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/5/21 0021.
 */

public interface HideCallback {
    void deleteTop();
}
