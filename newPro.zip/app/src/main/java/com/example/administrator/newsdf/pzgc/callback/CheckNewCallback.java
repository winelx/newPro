package com.example.administrator.newsdf.pzgc.callback;

/**
 * Created by Administrator on 2018/8/30 0030.
 */

public interface CheckNewCallback {
    void  updata();
}
